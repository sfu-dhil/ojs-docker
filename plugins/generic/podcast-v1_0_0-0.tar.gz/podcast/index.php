<?php

return new \APP\plugins\generic\podcast\PodcastPlugin();
