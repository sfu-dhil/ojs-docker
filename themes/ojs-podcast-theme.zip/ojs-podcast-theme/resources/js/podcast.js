import Plyr from 'plyr';

window.addEventListener('DOMContentLoaded', init);

function init(){
    const audio = document.querySelector('audio');
    console.log(audio);
    //audio.parentElement.classList.add('plyr');
    const player = new Plyr(audio, {
        'title': 'Some title',
        'debug': true
    });

    console.log(player);

}
